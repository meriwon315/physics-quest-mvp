import PhysicsQuestApp from "./components/PhysicsQuestApp";

export default function Home() {
  return <PhysicsQuestApp />;
}
